<?php
    // Open (or create) the SQLite database
    $db = new SQLite3('trespalabras.db');
    
    // Set busy timeout to 5 seconds (5000 ms) to wait if the database is locked
    $db->busyTimeout(5000);
    
    // Enable Write-Ahead Logging (WAL) mode for improved concurrent access
    $db->exec("PRAGMA journal_mode = WAL;");
    
    // Create the table if it doesn't already exist
    $query = "CREATE TABLE IF NOT EXISTS palabras (
         id INTEGER PRIMARY KEY AUTOINCREMENT,
         previas TEXT NOT NULL,
         siguiente TEXT NOT NULL
    )";
    $db->exec($query);
    
    // Read the contents of the text file
    $archivo = file_get_contents("consumir/quijote.txt");
    $reemplazado = str_replace("\n", " ", $archivo);
    $partido = explode(" ", $reemplazado);
    
    // Convert all words to lowercase
    for ($i = 0; $i < count($partido); $i++){
        $partido[$i] = strtolower($partido[$i]);
    }
    
    // Begin a transaction to improve performance and reduce locking issues
    $db->exec('BEGIN');
    
    // Prepare the statement once before the loop
    $stmt = $db->prepare("INSERT INTO palabras (previas, siguiente) VALUES (:previas, :siguiente)");
    if (!$stmt) {
        die("Failed to prepare statement: " . $db->lastErrorMsg());
    }
    
    // Loop through the words, ensuring we don't go out of bounds
    for ($i = 0; $i < count($partido) - 3; $i++){
        $previas = $partido[$i] . " " . $partido[$i+1] . " " . $partido[$i+2];
        $siguiente = $partido[$i+3];
        
        $stmt->bindValue(':previas', $previas, SQLITE3_TEXT);
        $stmt->bindValue(':siguiente', $siguiente, SQLITE3_TEXT);
        $stmt->execute();
    }
    
    // Commit the transaction
    $db->exec('COMMIT');
    
    echo "ok finalizado";
    $db->close();
?>
