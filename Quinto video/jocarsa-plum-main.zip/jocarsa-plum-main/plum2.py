#!/usr/bin/env python3
import os
import json

def get_size(path):
    """Get the size of a file or directory."""
    try:
        if os.path.isfile(path):
            return os.path.getsize(path)
        elif os.path.isdir(path):
            total_size = 0
            for dirpath, dirnames, filenames in os.walk(path):
                for f in filenames:
                    fp = os.path.join(dirpath, f)
                    # Skip if it's a broken symlink
                    if not os.path.islink(fp):
                        total_size += os.path.getsize(fp)
            return total_size
    except (OSError, PermissionError):
        return None

def list_files_and_folders_recursive(root, folders_only=False):
    """
    Recursively list all files and folders in the given root directory.
    
    Returns a list of dicts with:
      - name
      - path
      - type (file or directory)
      - size
      - contents (for directories)
    """
    structure = []
    try:
        for entry in os.scandir(root):
            if entry.is_dir():
                structure.append({
                    'name': entry.name,
                    'path': entry.path,
                    'type': 'directory',
                    'size': get_size(entry.path),
                    'contents': list_files_and_folders_recursive(entry.path, folders_only)
                })
            elif not folders_only:
                structure.append({
                    'name': entry.name,
                    'path': entry.path,
                    'type': 'file',
                    'size': get_size(entry.path)
                })
    except (OSError, PermissionError):
        pass
    return structure

def transform_for_d3_percentage(data, parent_name="root"):
    """
    Transform our file structure into a hierarchical structure that
    we can later use with d3.hierarchy() to compute aggregated sizes.
    
    We make sure every node (folder) carries its aggregated size.
    Leaf nodes (files) are represented with a "value" field.
    """
    node = {
        "name": parent_name,
    }
    
    # If data is a list (as produced by list_files_and_folders_recursive)
    if isinstance(data, list):
        children = []
        for item in data:
            if item['type'] == 'directory':
                children.append(transform_for_d3_percentage(item['contents'], parent_name=item['path']))
            else:
                children.append({
                    "name": item['path'],
                    "value": item.get('size', 0)
                })
        if children:
            node["children"] = children
        else:
            node["value"] = 0
    else:
        # In case data is a single dict (a directory entry)
        if data.get("type") == "directory":
            node["name"] = data.get("path")
            node["children"] = transform_for_d3_percentage(data.get("contents", []), parent_name=data.get("path")).get("children", [])
        else:
            node["name"] = data.get("path")
            node["value"] = data.get("size", 0)
    return node

def create_html_percentage_chart(data, html_file):
    """
    Create an HTML file that:
      - Shows a login form (username/password both 'jocarsa').
      - Upon login, displays a bar chart where each bar represents a folder.
      - Each bar’s width corresponds to the percentage of the folder’s aggregated size
        relative to the total size (100%).
      - The folder path and percentage is shown on each bar.
      - Includes simple but professional CSS styling.
    """
    json_data = json.dumps(data)
    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <title>Folder Size Percentage Chart</title>
  <style>
    /* Reset & Body */
    * {{
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }}
    body {{
      font-family: "Open Sans", Arial, sans-serif;
      background: #f4f7f9;
      color: #333;
      padding: 20px;
    }}
    /* Center Container */
    .center-container {{
      max-width: 900px;
      margin: 0 auto;
    }}
    /* Login Card */
    .login-card {{
      background: #fff;
      border-radius: 8px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      max-width: 400px;
      width: 100%;
      padding: 30px;
      margin-bottom: 20px;
    }}
    .login-card h1 {{
      text-align: center;
      margin-bottom: 20px;
      color: #2c3e50;
    }}
    .login-card label {{
      display: block;
      margin: 10px 0 5px;
      font-weight: 600;
    }}
    .login-card input[type="text"],
    .login-card input[type="password"] {{
      width: 100%;
      padding: 10px;
      border: 1px solid #dfe3e8;
      border-radius: 4px;
      margin-bottom: 10px;
      font-size: 14px;
    }}
    .login-card button {{
      background: #3498db;
      border: none;
      border-radius: 4px;
      width: 100%;
      padding: 12px;
      font-size: 16px;
      color: #fff;
      font-weight: 600;
      cursor: pointer;
    }}
    .login-card button:hover {{
      background: #2980b9;
    }}
    .error-msg {{
      color: #c0392b;
      font-weight: 600;
      margin: 5px 0 0;
      min-height: 18px;
    }}
    /* Chart Container */
    #chart-container {{
      display: none;
    }}
    .chart-title {{
      font-size: 26px;
      font-weight: 600;
      color: #2c3e50;
      margin-bottom: 20px;
      text-align: center;
    }}
    /* Bar Chart Styles */
    .bar-chart {{
      width: 100%;
      margin-top: 20px;
    }}
    .bar {{
      background: #27ae60;
      margin: 5px 0;
      border-radius: 4px;
      position: relative;
      color: #fff;
      /* Extra right padding so percentage text is visible even for narrow bars */
      padding: 5px 60px 5px 10px;
    }}
    .bar-label {{
      position: absolute;
      left: 10px;
      top: 50%;
      transform: translateY(-50%);
      font-size: 14px;
    }}
    .bar-percentage {{
      position: absolute;
      right: 10px;
      top: 50%;
      transform: translateY(-50%);
      font-size: 14px;
      font-weight: 600;
      color: #fff;
      pointer-events: none;
    }}
  </style>
</head>
<body>
  <div class="center-container">
    <!-- LOGIN FORM -->
    <div class="login-card" id="login-card">
      <h1>Login</h1>
      <label for="username">Username</label>
      <input type="text" id="username" placeholder="Username" />
      <label for="password">Password</label>
      <input type="password" id="password" placeholder="Password" />
      <button onclick="attemptLogin()">Sign In</button>
      <div class="error-msg" id="error-msg"></div>
    </div>

    <!-- CHART CONTAINER (hidden until login) -->
    <div id="chart-container">
      <div class="chart-title">Folder Size Percentage</div>
      <div id="bar-chart" class="bar-chart"></div>
    </div>
  </div>

  <!-- D3.js v7 from CDN -->
  <script src="https://d3js.org/d3.v7.min.js"></script>
  <script>
    const VALID_USER = "david";
    const VALID_PASS = "david";
    // Our hierarchical data (folders and files)
    const data = {json_data};

    function attemptLogin() {{
      const userField = document.getElementById("username");
      const passField = document.getElementById("password");
      const errMsg    = document.getElementById("error-msg");

      if (userField.value === VALID_USER && passField.value === VALID_PASS) {{
        document.getElementById("login-card").style.display = "none";
        document.getElementById("chart-container").style.display = "block";
        initPercentageChart();
      }} else {{
        errMsg.textContent = "Invalid username or password";
      }}
    }}

    // Use d3.hierarchy to compute aggregated sizes for directories.
    function initPercentageChart() {{
      // Create a hierarchy; for files (leaf nodes) we use d.value.
      const root = d3.hierarchy(data)
                     .sum(d => d.value ? d.value : 0)
                     .sort((a, b) => b.value - a.value);
      // The total size is the aggregated value of the root.
      const totalSize = root.value;

      // Filter to get only folders (nodes that have children) including the root.
      const folders = root.descendants().filter(d => d.children);

      // Prepare data: for each folder, compute its percentage.
      const folderData = folders.map(d => {{
